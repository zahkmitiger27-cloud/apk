// ============================================================================
// ZAHKMI TIGER STORE - APK malware scanner (Supabase Edge Function)
// Deploy:  supabase functions deploy scan-apk
// Secret:  supabase secrets set VT_API_KEY=your_virustotal_api_key
// Invoke:  POST { appId }  (admin JWT required)
// Uses VirusTotal API v3. Without VT_API_KEY it marks the scan as 'failed'
// and leaves the app in 'scanning' status for manual review.
// ============================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const VT_API_KEY = Deno.env.get("VT_API_KEY") ?? "";
const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ error: "POST only" }, 405);

  // Verify caller is an admin (defense in depth on top of RLS)
  const authHeader = req.headers.get("Authorization") ?? "";
  const anon = createClient(SB_URL, Deno.env.get("SUPABASE_ANON_KEY")!);
  const { data: { user } } = await anon.auth.getUser(authHeader.replace("Bearer ", ""));
  if (!user) return json({ error: "Unauthorized" }, 401);

  const admin = createClient(SB_URL, SB_SERVICE);
  const { data: profile } = await admin.from("profiles").select("is_admin,is_super_admin").eq("id", user.id).single();
  if (!profile || (!profile.is_admin && !profile.is_super_admin)) {
    return json({ error: "Admin only" }, 403);
  }

  const { appId } = await req.json().catch(() => ({}));
  if (!appId) return json({ error: "appId required" }, 400);

  const { data: app } = await admin.from("apps").select("*").eq("id", appId).single();
  if (!app || !app.apk_path) return json({ error: "App or APK not found" }, 404);

  await admin.from("apps").update({ status: "scanning", scan_status: "scanning" }).eq("id", appId);

  if (!VT_API_KEY) {
    await admin.from("apps").update({ scan_status: "failed" }).eq("id", appId);
    return json({ ok: false, message: "VT_API_KEY not configured - set it with: supabase secrets set VT_API_KEY=..." });
  }

  try {
    // 1. Download the APK from private storage (service role bypasses RLS)
    const { data: file, error: dlErr } = await admin.storage.from("apks").download(app.apk_path);
    if (dlErr || !file) throw new Error("download failed: " + (dlErr?.message ?? "empty"));

    // 2. Submit to VirusTotal
    const form = new FormData();
    form.append("file", new Blob([await file.arrayBuffer()]), app.apk_path.split("/").pop() ?? "app.apk");
    const vtUp = await fetch("https://www.virustotal.com/api/v3/files", {
      method: "POST",
      headers: { "x-apikey": VT_API_KEY },
      body: form,
    });
    if (!vtUp.ok) throw new Error("VirusTotal upload failed: " + vtUp.status);
    const upJson = await vtUp.json();
    const analysisId = upJson.data.id as string;

    // 3. Poll for the verdict (max ~2 minutes)
    let verdict: any = null;
    for (let i = 0; i < 24; i++) {
      await new Promise((r) => setTimeout(r, 5000));
      const res = await fetch(`https://www.virustotal.com/api/v3/analyses/${analysisId}`, {
        headers: { "x-apikey": VT_API_KEY },
      });
      const j = await res.json();
      if (j.data?.attributes?.status === "completed") { verdict = j.data.attributes.stats; break; }
    }
    if (!verdict) throw new Error("scan timed out");

    const bad = (verdict.malicious ?? 0) + (verdict.suspicious ?? 0);
    const clean = bad === 0;
    await admin.from("apps").update({
      status: clean ? "approved" : "infected",
      scan_status: clean ? "clean" : "infected",
    }).eq("id", appId);

    return json({ ok: clean, stats: verdict });
  } catch (e) {
    await admin.from("apps").update({ scan_status: "failed" }).eq("id", appId);
    return json({ ok: false, error: String(e) }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
}
