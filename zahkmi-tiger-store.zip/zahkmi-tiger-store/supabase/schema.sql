-- ============================================================================
-- ZAHKMI TIGER STORE - Supabase database schema, RLS policies & storage
-- Run this in: Supabase Dashboard -> SQL Editor -> New query -> Run
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- PROFILES (auto-created on signup)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text not null,
  display_name  text,
  avatar_url    text,
  is_admin      boolean not null default false,
  is_super_admin boolean not null default false,
  created_at    timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Server-side admin checks (security definer: users cannot fake these)
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and (is_admin or is_super_admin)
  );
$$;

create or replace function public.is_super_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.profiles where id = auth.uid() and is_super_admin
  );
$$;

-- Auto-create a profile row when a user signs up
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', split_part(new.email, '@', 1))
  );
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ONLY the Super Admin may change admin flags (enforced server-side)
create or replace function public.protect_admin_flags()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (new.is_admin is distinct from old.is_admin
      or new.is_super_admin is distinct from old.is_super_admin)
     and not public.is_super_admin() then
    raise exception 'Only the ZAHKMI TIGER Super Admin can change admin permissions';
  end if;
  return new;
end $$;

drop trigger if exists trg_protect_admin on public.profiles;
create trigger trg_protect_admin
  before update on public.profiles
  for each row execute function public.protect_admin_flags();

create policy "profiles: select own or admin" on public.profiles
  for select using (auth.uid() = id or public.is_admin());
create policy "profiles: update own" on public.profiles
  for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "profiles: super admin updates anyone" on public.profiles
  for update using (public.is_super_admin()) with check (public.is_super_admin());
create policy "profiles: super admin deletes" on public.profiles
  for delete using (public.is_super_admin());

-- ---------------------------------------------------------------------------
-- CATEGORIES
-- ---------------------------------------------------------------------------
create table if not exists public.categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique,
  slug       text not null unique,
  created_at timestamptz not null default now()
);

alter table public.categories enable row level security;

create policy "categories: public read" on public.categories for select using (true);
create policy "categories: admin write" on public.categories for all
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- APPS  (APK bytes live in Storage; only metadata lives here)
-- ---------------------------------------------------------------------------
create table if not exists public.apps (
  id               uuid primary key default gen_random_uuid(),
  developer_id     uuid references public.profiles(id) on delete set null,
  category_id      uuid references public.categories(id) on delete set null,
  name             text not null,
  slug             text not null unique,
  package_name     text,
  short_desc       text,
  description      text,
  version          text not null default '1.0',
  file_size_bytes  bigint not null default 0,
  icon_url         text,
  screenshots      jsonb not null default '[]',
  apk_path         text,                      -- storage object key, never the file itself
  status           text not null default 'pending'
                   check (status in ('pending','scanning','approved','rejected','infected')),
  scan_status      text not null default 'pending'
                   check (scan_status in ('pending','scanning','clean','infected','failed')),
  rejection_reason text,
  featured         boolean not null default false,
  downloads_count  bigint not null default 0,
  rating_avg       numeric(3,2) not null default 0,
  rating_count     int not null default 0,
  created_at       timestamptz not null default now()
);

alter table public.apps enable row level security;

create policy "apps: public read approved" on public.apps
  for select using (status = 'approved' or developer_id = auth.uid() or public.is_admin());
create policy "apps: auth users submit" on public.apps
  for insert with check (auth.uid() = developer_id);
create policy "apps: admin update" on public.apps
  for update using (public.is_admin()) with check (public.is_admin());
create policy "apps: owner or admin delete" on public.apps
  for delete using (developer_id = auth.uid() or public.is_admin());

-- Download counter (callable by anyone for approved apps, tamper-resistant)
create or replace function public.increment_downloads(p_app_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.apps
     set downloads_count = downloads_count + 1
   where id = p_app_id and status = 'approved';
end $$;

-- ---------------------------------------------------------------------------
-- REVIEWS
-- ---------------------------------------------------------------------------
create table if not exists public.reviews (
  id         uuid primary key default gen_random_uuid(),
  app_id     uuid not null references public.apps(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  rating     int not null check (rating between 1 and 5),
  comment    text,
  created_at timestamptz not null default now(),
  unique (app_id, user_id)
);

alter table public.reviews enable row level security;

create policy "reviews: public read" on public.reviews for select using (true);
create policy "reviews: users write own" on public.reviews
  for insert with check (auth.uid() = user_id);
create policy "reviews: users update own" on public.reviews
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "reviews: owner or admin delete" on public.reviews
  for delete using (auth.uid() = user_id or public.is_admin());

create or replace function public.recompute_rating(p_app_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare avg_r numeric; cnt int;
begin
  select avg(rating), count(*) into avg_r, cnt
    from public.reviews where app_id = p_app_id;
  update public.apps
     set rating_avg = coalesce(avg_r, 0), rating_count = coalesce(cnt, 0)
   where id = p_app_id;
end $$;

create or replace function public.reviews_changed()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  perform public.recompute_rating(coalesce(new.app_id, old.app_id));
  return coalesce(new, old);
end $$;

drop trigger if exists trg_reviews_changed on public.reviews;
create trigger trg_reviews_changed
  after insert or update or delete on public.reviews
  for each row execute function public.reviews_changed();

-- ---------------------------------------------------------------------------
-- FAVORITES
-- ---------------------------------------------------------------------------
create table if not exists public.favorites (
  user_id    uuid not null references public.profiles(id) on delete cascade,
  app_id     uuid not null references public.apps(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, app_id)
);

alter table public.favorites enable row level security;

create policy "favorites: owner read"  on public.favorites for select using (auth.uid() = user_id);
create policy "favorites: owner write" on public.favorites for insert with check (auth.uid() = user_id);
create policy "favorites: owner delete" on public.favorites for delete using (auth.uid() = user_id);

-- ---------------------------------------------------------------------------
-- DOWNLOAD HISTORY
-- ---------------------------------------------------------------------------
create table if not exists public.downloads (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id) on delete cascade,
  app_id     uuid not null references public.apps(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.downloads enable row level security;

create policy "downloads: owner read"   on public.downloads for select using (auth.uid() = user_id);
create policy "downloads: owner insert" on public.downloads for insert with check (auth.uid() = user_id);

-- ---------------------------------------------------------------------------
-- REPORTS (users report apps; admins handle them)
-- ---------------------------------------------------------------------------
create table if not exists public.reports (
  id         uuid primary key default gen_random_uuid(),
  app_id     uuid not null references public.apps(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  reason     text not null,
  details    text,
  status     text not null default 'open' check (status in ('open','resolved','dismissed')),
  created_at timestamptz not null default now()
);

alter table public.reports enable row level security;

create policy "reports: users create" on public.reports for insert with check (auth.uid() = user_id);
create policy "reports: admin read"   on public.reports for select using (public.is_admin());
create policy "reports: admin update" on public.reports
  for update using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- SUPPORT TICKETS
-- ---------------------------------------------------------------------------
create table if not exists public.support_tickets (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references public.profiles(id) on delete set null,
  subject    text not null,
  message    text not null,
  status     text not null default 'open' check (status in ('open','answered','closed')),
  reply      text,
  created_at timestamptz not null default now()
);

alter table public.support_tickets enable row level security;

create policy "tickets: users create" on public.support_tickets for insert with check (auth.uid() = user_id);
create policy "tickets: users read own" on public.support_tickets for select using (auth.uid() = user_id or public.is_admin());
create policy "tickets: admin update" on public.support_tickets
  for update using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- STORAGE BUCKETS
--   store-assets : public  -> app icons & screenshots
--   apks         : private -> APK binaries (served only via signed URLs for
--                             approved apps, uploaded only to the uploader's folder)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
  values ('store-assets', 'store-assets', true) on conflict do nothing;
insert into storage.buckets (id, name, public)
  values ('apks', 'apks', false) on conflict do nothing;

-- Public read for icons/screenshots; any signed-in user may upload; admin manages.
create policy "assets: public read" on storage.objects for select
  using (bucket_id = 'store-assets');
create policy "assets: auth upload" on storage.objects for insert
  with check (bucket_id = 'store-assets' and auth.role() = 'authenticated');
create policy "assets: admin update/delete" on storage.objects for update
  using (bucket_id = 'store-assets' and public.is_admin());
create policy "assets: admin delete" on storage.objects for delete
  using (bucket_id = 'store-assets' and public.is_admin());

-- APK policies: uploader's own folder only, validated .apk extension
create policy "apks: upload own folder" on storage.objects for insert
  with check (
    bucket_id = 'apks'
    and auth.uid()::text = (storage.foldername(name))[1]
    and lower(name) like '%.apk'
  );
-- Only signed URLs for APKs of APPROVED apps can be created (public never sees others)
create policy "apks: read approved apps only" on storage.objects for select
  using (
    bucket_id = 'apks'
    and exists (
      select 1 from public.apps a where a.apk_path = storage.objects.name and a.status = 'approved'
    )
  );
create policy "apks: admin update" on storage.objects for update
  using (bucket_id = 'apks' and public.is_admin());
create policy "apks: admin delete" on storage.objects for delete
  using (bucket_id = 'apks' and public.is_admin());

-- ---------------------------------------------------------------------------
-- SUPER ADMIN BOOTSTRAP (IMPORTANT - owner does this once)
-- ---------------------------------------------------------------------------
-- 1. Sign up in your app with YOUR owner email first.
-- 2. Then run (replace with your real email):
--
--   update public.profiles
--      set is_super_admin = true
--    where email = 'owner@yourdomain.com';
--
-- After that, ONLY that account can grant/revoke admin rights from the
-- Admin -> Users panel. Nobody else can elevate themselves.
