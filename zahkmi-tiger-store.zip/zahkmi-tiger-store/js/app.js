/* ============================================================================
   ZAHKMI TIGER STORE - SPA router + all pages (wired to Supabase backend)
   ========================================================================== */
'use strict';

const view = () => document.getElementById('view');

/* ---------------- shell helpers ---------------- */
function page(html) { view().innerHTML = html; window.scrollTo(0, 0); }
function loading() { return '<div class="loading"><div class="spinner"></div><div>Loading…</div></div>'; }
function empty(msg, icon) { return '<div class="empty"><span class="big">' + (icon || '🐯') + '</span>' + esc(msg) + '</div>'; }
function errBox(e) { return '<div class="panel" style="border-color:var(--red)"><b style="color:var(--red)">Error:</b> ' + esc(e.message || e) + '</div>'; }
function fmtInt(n) { n = Number(n) || 0; return n >= 1e6 ? (n / 1e6).toFixed(1) + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1) + 'K' : String(n); }
function needsSetup() { return CFG.SUPABASE_URL.indexOf('YOUR-') !== -1; }
function setupBanner() {
  if (!needsSetup()) return '';
  return '<div class="panel" style="border-color:var(--amber);margin-bottom:20px">'
    + '<b style="color:var(--amber)">⚠ Setup required.</b> <span class="hint" style="margin:0">'
    + '1) Create a free Supabase project → 2) run <code>supabase/schema.sql</code> in the SQL editor → '
    + '3) paste your project URL + anon key into <code>js/config.js</code> → 4) reload. '
    + 'Full steps are in <code>README.md</code>.</span></div>';
}
function statusBadge(a) {
  return '<span class="badge-status st-' + esc(a.status) + '">' + esc(a.status) + '</span>'
    + ' <span class="badge-status st-' + esc(a.scan_status) + '">scan: ' + esc(a.scan_status) + '</span>';
}
function appCard(a, opts) {
  opts = opts || {};
  const icon = a.icon_url ? '<img src="' + esc(a.icon_url) + '" alt="">' : esc(initials(a.name));
  const dev = a.profiles ? (a.profiles.display_name || a.profiles.email) : 'ZTS developer';
  return '<a class="appcard" href="#/app/' + esc(a.slug) + '">'
    + (a.featured ? '<span class="badge-feat">FEATURED</span>' : '')
    + (opts.showStatus ? '<div style="margin-bottom:6px">' + statusBadge(a) + '</div>' : '')
    + '<div class="icon">' + icon + '</div>'
    + '<h3>' + esc(a.name) + '</h3>'
    + '<div class="dev">' + esc(dev) + '</div>'
    + '<div class="meta">' + stars(a.rating_avg) + '<span>⬇ ' + fmtInt(a.downloads_count) + '</span><span>' + fmtSize(a.file_size_bytes) + '</span></div>'
    + '</a>';
}
function sectionGrid(title, id, moreHref) {
  return '<section class="section"><div class="sec-head"><h2>' + esc(title) + '</h2>'
    + (moreHref ? '<a href="' + moreHref + '">See all →</a>' : '') + '</div>'
    + '<div class="grid" id="' + id + '">' + loading() + '</div></section>';
}
function heroHtml(counts) {
  return '<section class="hero">'
    + '<div class="kicker pulse">// the neon app marketplace</div>'
    + '<h1>Download apps on <span>ZAHKMI TIGER STORE</span></h1>'
    + '<p>Discover original apps, scan-verified APKs, honest reviews and a store owned by the community. Built independent — not affiliated with Google.</p>'
    + '<div class="hero-cta"><a class="btn btn-primary" href="#/categories">Browse categories</a>'
    + '<a class="btn btn-purple" href="#/submit">Publish your app</a></div>'
    + '<div class="hero-stats">'
    + '<div class="stat"><b>' + fmtInt(counts.apps) + '</b><span>Apps</span></div>'
    + '<div class="stat"><b>' + fmtInt(counts.downloads) + '</b><span>Downloads</span></div>'
    + '<div class="stat"><b>' + fmtInt(counts.users) + '</b><span>Members</span></div>'
    + '</div></section>';
}

/* ---------------- pages: store ---------------- */
async function renderHome() {
  page(setupBanner() + heroHtml({ apps: '–', downloads: '–', users: '–' })
    + sectionGrid('Featured', 'g-featured')
    + '<section class="section"><div class="sec-head"><h2>Categories</h2><a href="#/categories">All →</a></div><div class="chips" id="chips">' + loading() + '</div></section>'
    + sectionGrid('Latest apps', 'g-latest', '#/search/'));
  try {
    const [featured, cats, latest, counts] = await Promise.all([
      listApprovedApps({ featured: true, limit: 8 }),
      listCategories(),
      listApprovedApps({ limit: 12 }),
      adminCounts(),
    ]);
    view().querySelector('.hero').outerHTML = heroHtml(counts);
    $('#g-featured').innerHTML = featured.length ? featured.map(a => appCard(a)).join('') : empty('No featured apps yet');
    $('#chips').innerHTML = cats.length ? cats.map(c => '<a class="chip" href="#/category/' + esc(c.slug) + '">' + esc(c.name) + '</a>').join('') : empty('No categories yet', '🗂️');
    $('#g-latest').innerHTML = latest.length ? latest.map(a => appCard(a)).join('') : empty('No apps published yet');
  } catch (e) { $('#g-latest').innerHTML = errBox(e); }
}

async function renderCategories() {
  page('<div class="sec-head"><h2>Categories</h2></div><div class="chips" id="chips">' + loading() + '</div>');
  try {
    const cats = await listCategories();
    $('#chips').innerHTML = cats.length ? cats.map(c =>
      '<a class="chip" href="#/category/' + esc(c.slug) + '" style="font-size:15px;padding:12px 22px">▸ ' + esc(c.name) + '</a>').join('')
      : empty('No categories yet — an admin can add them from the Admin panel', '🗂️');
  } catch (e) { $('#chips').innerHTML = errBox(e); }
}

async function renderCategory(slug) {
  page(sectionGrid('Category: ' + slug, 'g-cat'));
  try {
    const apps = await listApprovedApps({ category: slug });
    const cats = await listCategories();
    const cat = cats.find(c => c.slug === slug);
    view().querySelector('h2').textContent = 'Category: ' + (cat ? cat.name : slug);
    $('#g-cat').innerHTML = apps.length ? apps.map(a => appCard(a)).join('') : empty('No apps in this category yet');
  } catch (e) { $('#g-cat').innerHTML = errBox(e); }
}

async function renderSearch(term) {
  page('<div class="sec-head"><h2>Search</h2></div>'
    + '<form class="searchbox" id="s2" style="max-width:480px;margin-bottom:20px"><input id="s2q" type="search" placeholder="Search apps…" value="' + esc(term || '') + '"><button type="submit">⌕</button></form>'
    + '<div class="grid" id="g-search">' + (term ? loading() : empty('Type a name or keyword to search', '🔍')) + '</div>');
  $('#s2').addEventListener('submit', ev => { ev.preventDefault(); location.hash = '#/search/' + encodeURIComponent($('#s2q').value.trim()); });
  if (!term) return;
  try {
    const apps = await searchApps(term);
    $('#g-search').innerHTML = apps.length ? apps.map(a => appCard(a)).join('') : empty('Nothing found for "' + term + '"', '🔍');
  } catch (e) { $('#g-search').innerHTML = errBox(e); }
}

async function renderAppDetail(slug) {
  page(loading());
  let app;
  try { app = await getApp(slug); } catch (e) { page(errBox(e)); return; }
  if (!app) { page(empty('App not found or not published yet')); return; }
  const s = await getSession();
  let reviews = [], mine = null, fav = false;
  try { reviews = await listReviews(app.id); } catch (e) {}
  if (s) { try { mine = await myReview(app.id); fav = await isFav(app.id); } catch (e) {} }
  const dev = app.profiles ? (app.profiles.display_name || app.profiles.email) : 'ZTS developer';
  const shots = (app.screenshots || []).map(u => '<img src="' + esc(u) + '" alt="screenshot" loading="lazy">').join('');
  page('<a href="#/" style="color:var(--muted);font-size:13px">← Back to store</a><div class="panel mt" style="padding:24px">'
    + '<div class="detail">'
    + '<div class="icon-big">' + (app.icon_url ? '<img src="' + esc(app.icon_url) + '" alt="">' : esc(initials(app.name))) + '</div>'
    + '<div><h1>' + esc(app.name) + '</h1>'
    + '<div class="devlink">' + esc(dev) + (app.categories ? ' · ' + esc(app.categories.name) : '') + '</div>'
    + '<div class="meta" style="margin-top:8px">' + stars(app.rating_avg) + ' <b>' + (Number(app.rating_avg) || 0).toFixed(1) + '</b>'
    + ' <span style="color:var(--muted)">(' + app.rating_count + ' reviews) · ⬇ ' + fmtInt(app.downloads_count) + ' downloads</span></div>'
    + '<div class="row-actions" style="margin-top:14px">'
    + '<button class="btn btn-primary" id="btn-install">⬇ Install</button>'
    + '<button class="btn btn-ghost" id="btn-fav">' + (fav ? '♥ Favorited' : '♡ Favorite') + '</button>'
    + (s ? '<a class="btn btn-ghost btn-sm" style="align-self:center" href="#/report/' + esc(app.slug) + '">⚑ Report</a>' : '')
    + '</div></div></div>'
    + '<div class="metagrid">'
    + '<div class="m"><b>' + esc(app.version) + '</b><span>Version</span></div>'
    + '<div class="m"><b>' + fmtSize(app.file_size_bytes) + '</b><span>Size</span></div>'
    + '<div class="m"><b>' + esc(app.scan_status) + '</b><span>Scan status</span></div>'
    + '<div class="m"><b>' + fmtDate(app.created_at) + '</b><span>Updated</span></div>'
    + '</div>'
    + (shots ? '<div class="sec-head" style="margin-top:8px"><h2>Screenshots</h2></div><div class="shots">' + shots + '</div>' : '')
    + '<div class="panel" style="margin-top:16px"><h3>About this app</h3><div class="longtext">' + esc(app.description || app.short_desc || 'No description provided.') + '</div></div>'
    + '</div>'
    + '<div class="panel mt-lg"><h3>Ratings & reviews</h3>'
    + (s ? reviewFormHtml(mine) : '<p class="hint"><a href="#/login" style="color:var(--green)">Log in</a> to write a review.</p>')
    + '<div id="reviews">' + (reviews.length ? reviews.map(r => reviewHtml(r, s)).join('') : '<p class="hint mt">No reviews yet — be the first.</p>') + '</div></div>');

  $('#btn-install').addEventListener('click', async ev => {
    const btn = ev.currentTarget; btn.disabled = true; btn.textContent = 'Preparing…';
    try { await installApp(app); toast('Download started — check your downloads', 'ok'); }
    catch (e) { toast(e.message || 'Download failed', 'error'); }
    btn.disabled = false; btn.innerHTML = '⬇ Install';
  });
  const favBtn = $('#btn-fav');
  if (favBtn) favBtn.addEventListener('click', async () => {
    try { const on = await toggleFav(app.id); favBtn.innerHTML = on ? '♥ Favorited' : '♡ Favorite'; toast(on ? 'Added to favorites' : 'Removed from favorites', 'ok'); }
    catch (e) { toast(e.message, 'error'); if (String(e.message).indexOf('Sign in') !== -1) location.hash = '#/login'; }
  });
  bindReviewForm(app, mine, s);
  $$('#reviews [data-del-review]').forEach(b => b.addEventListener('click', async () => {
    try { await deleteReview(b.dataset.delReview); toast('Review deleted', 'ok'); renderAppDetail(slug); }
    catch (e) { toast(e.message, 'error'); }
  }));
}
function reviewFormHtml(mine) {
  const r = mine ? mine.rating : 0;
  let btns = '';
  for (let i = 1; i <= 5; i++) btns += '<button type="button" data-star="' + i + '" class="' + (i <= r ? 'on' : '') + '">★</button>';
  return '<form id="review-form" style="margin-bottom:18px">'
    + '<input type="hidden" id="rv-rating" value="' + r + '">'
    + '<div class="stars-input" id="rv-stars">' + btns + '</div>'
    + '<div class="field mt"><textarea id="rv-comment" placeholder="Share your experience…">' + esc(mine ? (mine.comment || '') : '') + '</textarea></div>'
    + '<button class="btn btn-primary btn-sm" type="submit">' + (mine ? 'Update review' : 'Post review') + '</button></form>';
}
function bindReviewForm(app, mine, s) {
  const form = $('#review-form'); if (!form) return;
  const starsBox = $('#rv-stars'), hidden = $('#rv-rating');
  starsBox.addEventListener('click', ev => {
    const b = ev.target.closest('[data-star]'); if (!b) return;
    hidden.value = b.dataset.star;
    $$('#rv-stars button').forEach(x => x.classList.toggle('on', Number(x.dataset.star) <= Number(hidden.value)));
  });
  form.addEventListener('submit', async ev => {
    ev.preventDefault();
    const rating = Number(hidden.value);
    if (!rating) { toast('Pick a star rating first', 'error'); return; }
    try { await saveReview(app.id, rating, $('#rv-comment').value.trim()); toast('Review saved — thanks!', 'ok'); renderAppDetail(app.slug); }
    catch (e) { toast(e.message, 'error'); }
  });
}
function reviewHtml(r, s) {
  const who = r.profiles ? (r.profiles.display_name || r.profiles.email) : 'Member';
  const mine = s && r.user_id === s.user.id;
  return '<div class="review"><div class="rh">' + avatarHtml(r.profiles) + '<b>' + esc(who) + '</b> ' + stars(r.rating)
    + '<time>' + timeAgo(r.created_at) + '</time></div>'
    + (r.comment ? '<p>' + esc(r.comment) + '</p>' : '')
    + (mine ? '<div class="row-actions" style="margin-top:6px"><button class="btn btn-ghost btn-sm" data-del-review="' + r.id + '">Delete</button></div>' : '')
    + '</div>';
}

/* ---------------- pages: auth ---------------- */
function authShell(title, sub, inner) {
  return '<div class="authwrap"><div class="form-card" style="width:100%">' + setupBanner()
    + '<h2>' + esc(title) + '</h2><div class="sub">' + esc(sub) + '</div>' + inner + '</div></div>';
}
function renderLogin() {
  page(authShell('Welcome back, tiger 🐯', 'Log in to ZAHKMI TIGER STORE',
    '<form id="f-login">'
    + '<div class="field"><label>Email</label><input type="email" id="l-email" required autocomplete="email"></div>'
    + '<div class="field"><label>Password</label><input type="password" id="l-pass" required autocomplete="current-password"></div>'
    + '<div class="err" id="l-err"></div>'
    + '<button class="btn btn-primary" style="width:100%" type="submit">Log in</button>'
    + '<div class="form-alt"><a href="#/reset">Forgot password?</a> · <a href="#/signup">Create account</a></div>'
    + '<div class="divider">or</div>'
    + '<button class="btn btn-ghost" style="width:100%" type="button" id="l-google">Continue with Google</button>'
    + '</form>'));
  $('#f-login').addEventListener('submit', async ev => {
    ev.preventDefault(); $('#l-err').textContent = '';
    try { await signIn($('#l-email').value.trim(), $('#l-pass').value); await afterAuth(); }
    catch (e) { $('#l-err').textContent = e.message; }
  });
  $('#l-google').addEventListener('click', async () => {
    try { await signInGoogle(); } catch (e) { toast('Google login is not configured yet — enable it in Supabase Auth settings (see README)', 'error'); }
  });
}
function renderSignup() {
  page(authShell('Join the pack', 'Create your ZAHKMI TIGER STORE account',
    '<form id="f-signup">'
    + '<div class="field"><label>Display name</label><input type="text" id="su-name" required></div>'
    + '<div class="field"><label>Email</label><input type="email" id="su-email" required autocomplete="email"></div>'
    + '<div class="field"><label>Password (min 6 chars)</label><input type="password" id="su-pass" required minlength="6" autocomplete="new-password"></div>'
    + '<div class="err" id="su-err"></div>'
    + '<button class="btn btn-primary" style="width:100%" type="submit">Create account</button>'
    + '<div class="form-alt">Already a member? <a href="#/login">Log in</a></div>'
    + '</form>'));
  $('#f-signup').addEventListener('submit', async ev => {
    ev.preventDefault(); $('#su-err').textContent = '';
    try {
      await signUp($('#su-email').value.trim(), $('#su-pass').value, $('#su-name').value.trim());
      toast('Account created — check your email to confirm (or disable confirmation in Supabase Auth settings)', 'ok');
      location.hash = '#/login';
    } catch (e) { $('#su-err').textContent = e.message; }
  });
}
function renderReset() {
  page(authShell('Reset password', 'We will email you a secure reset link',
    '<form id="f-reset">'
    + '<div class="field"><label>Email</label><input type="email" id="r-email" required></div>'
    + '<div class="err" id="r-err"></div>'
    + '<button class="btn btn-primary" style="width:100%" type="submit">Send reset link</button>'
    + '<div class="form-alt"><a href="#/login">← Back to login</a></div></form>'));
  $('#f-reset').addEventListener('submit', async ev => {
    ev.preventDefault(); $('#r-err').textContent = '';
    try { await sendReset($('#r-email').value.trim()); toast('Reset link sent — check your inbox', 'ok'); }
    catch (e) { $('#r-err').textContent = e.message; }
  });
}
async function afterAuth() {
  await refreshAuthZone(); toast('Welcome to ZAHKMI TIGER STORE', 'ok');
  location.hash = '#/'; route();
}

/* ---------------- pages: account ---------------- */
async function requireLogin() {
  const s = await getSession();
  if (!s) { location.hash = '#/login'; return null; }
  return s;
}
async function renderProfile() {
  const s = await requireLogin(); if (!s) return;
  const p = await getProfile();
  page('<div class="two-col">'
    + '<div class="panel"><h3>My profile</h3>'
    + '<div style="display:flex;align-items:center;gap:14px;margin-bottom:16px">' + avatarHtml(p)
    + '<div><b style="font-size:18px">' + esc(p.display_name || '') + '</b>'
    + (p.is_super_admin ? ' <span class="badge-status st-infected" style="background:var(--purple)">SUPER ADMIN</span>'
      : p.is_admin ? ' <span class="badge-status st-approved">ADMIN</span>' : '')
    + '<div class="hint" style="margin:0">' + esc(p.email) + ' · joined ' + fmtDate(p.created_at) + '</div></div></div>'
    + '<form id="f-prof">'
    + '<div class="field"><label>Display name</label><input type="text" id="p-name" value="' + esc(p.display_name || '') + '"></div>'
    + '<div class="field"><label>Avatar image</label><input type="file" id="p-avatar" accept="image/*"><div class="hint">PNG/JPG/WebP, max 2 MB</div></div>'
    + '<button class="btn btn-primary btn-sm" type="submit">Save profile</button></form>'
    + '<div style="margin-top:20px;border-top:1px solid var(--line);padding-top:16px">'
    + '<h3>Change password</h3><form id="f-pass">'
    + '<div class="field"><label>New password</label><input type="password" id="p-pass" minlength="6" required></div>'
    + '<button class="btn btn-ghost btn-sm" type="submit">Update password</button></form></div></div>'
    + '<div>'
    + '<div class="panel"><h3>Quick links</h3><div class="row-actions">'
    + '<a class="btn btn-ghost btn-sm" href="#/favorites">♥ Favorites</a>'
    + '<a class="btn btn-ghost btn-sm" href="#/downloads">⬇ Download history</a>'
    + (p.is_admin || p.is_super_admin ? '<a class="btn btn-purple btn-sm" href="#/admin">⚡ Admin panel</a>' : '')
    + '</div></div>'
    + '<div class="panel mt-lg"><h3>My submissions</h3><div id="my-apps">' + loading() + '</div></div>'
    + '</div></div>');
  $('#f-prof').addEventListener('submit', async ev => {
    ev.preventDefault();
    try {
      const patch = { display_name: $('#p-name').value.trim() };
      const f = $('#p-avatar').files[0];
      if (f) { validateImage(f); patch.avatar_url = await uploadAsset(f, 'avatars'); }
      await updateProfileFields(patch); toast('Profile saved', 'ok'); await refreshAuthZone(); renderProfile();
    } catch (e) { toast(e.message, 'error'); }
  });
  $('#f-pass').addEventListener('submit', async ev => {
    ev.preventDefault();
    try { await updatePassword($('#p-pass').value); $('#p-pass').value = ''; toast('Password updated', 'ok'); }
    catch (e) { toast(e.message, 'error'); }
  });
  try {
    const mine = await sb.from('apps').select('*').eq('developer_id', s.user.id).order('created_at', { ascending: false });
    const rows = (mine.data || []);
    $('#my-apps').innerHTML = rows.length ? '<div class="tablewrap"><table class="admin"><tr><th>App</th><th>Status</th><th>⬇</th></tr>'
      + rows.map(a => '<tr><td><a href="#/app/' + esc(a.slug) + '" style="color:var(--cyan)">' + esc(a.name) + '</a><div class="hint" style="margin:0">v' + esc(a.version) + '</div></td>'
        + '<td>' + statusBadge(a) + (a.rejection_reason ? '<div class="hint" style="margin:0;color:var(--red)">' + esc(a.rejection_reason) + '</div>' : '') + '</td>'
        + '<td>' + fmtInt(a.downloads_count) + '</td></tr>').join('') + '</table></div>'
      : empty('You have not submitted any apps yet', '📦');
  } catch (e) { $('#my-apps').innerHTML = errBox(e); }
}
async function renderFavorites() {
  const s = await requireLogin(); if (!s) return;
  page('<div class="sec-head"><h2>My favorites</h2></div><div class="grid" id="g">' + loading() + '</div>');
  try { const apps = await listFavorites(); $('#g').innerHTML = apps.length ? apps.map(a => appCard(a)).join('') : empty('No favorites yet — tap ♡ on any app', '♥'); }
  catch (e) { $('#g').innerHTML = errBox(e); }
}
async function renderDownloads() {
  const s = await requireLogin(); if (!s) return;
  page('<div class="sec-head"><h2>Download history</h2></div><div id="g">' + loading() + '</div>');
  try {
    const rows = await listMyDownloads();
    $('#g').innerHTML = rows.length ? '<div class="tablewrap"><table class="admin"><tr><th>App</th><th>Downloaded</th></tr>'
      + rows.map(r => '<tr><td>' + (r.app ? '<a href="#/app/' + esc(r.app.slug) + '" style="color:var(--cyan)">' + esc(r.app.name) + '</a>' : '(deleted app)') + '</td><td>' + fmtDate(r.at) + '</td></tr>').join('')
      + '</table></div>' : empty('No downloads yet', '⬇');
  } catch (e) { $('#g').innerHTML = errBox(e); }
}

/* ---------------- pages: submit / support / report / legal ---------------- */
function appFormHtml(adminMode) {
  return '<form id="f-app" enctype="multipart/form-data">'
    + '<div class="two-col">'
    + '<div>'
    + '<div class="field"><label>App name *</label><input type="text" id="a-name" required maxlength="60"></div>'
    + '<div class="field"><label>Package name</label><input type="text" id="a-pkg" placeholder="com.example.myapp"></div>'
    + '<div class="field"><label>Version *</label><input type="text" id="a-ver" value="1.0" required></div>'
    + '<div class="field"><label>Category</label><select id="a-cat"><option value="">Loading…</option></select></div>'
    + '</div><div>'
    + '<div class="field"><label>App icon *</label><input type="file" id="a-icon" accept="image/*" required><div class="hint">PNG/JPG/WebP, square looks best</div></div>'
    + '<div class="field"><label>Screenshots (up to 6)</label><input type="file" id="a-shots" accept="image/*" multiple></div>'
    + '<div class="field"><label>APK file *</label><input type="file" id="a-apk" accept=".apk,application/vnd.android.package-archive" required><div class="hint">.apk only, max ' + fmtSize(CFG.MAX_APK_BYTES) + ' — scanned for malware before publishing</div></div>'
    + '</div></div>'
    + '<div class="field"><label>Short description</label><input type="text" id="a-short" maxlength="120" placeholder="One catchy line"></div>'
    + '<div class="field"><label>Full description *</label><textarea id="a-desc" required placeholder="What does your app do? Features, permissions, requirements…"></textarea></div>'
    + '<div class="err" id="a-err"></div>'
    + '<button class="btn ' + (adminMode ? 'btn-purple' : 'btn-primary') + '" type="submit" id="a-submit">'
    + (adminMode ? 'Upload & scan APK' : 'Submit for review') + '</button></form>';
}
async function bindAppForm(adminMode, onDone) {
  const cats = await listCategories().catch(() => []);
  $('#a-cat').innerHTML = '<option value="">— choose —</option>' + cats.map(c => '<option value="' + c.id + '">' + esc(c.name) + '</option>').join('');
  $('#f-app').addEventListener('submit', async ev => {
    ev.preventDefault();
    const err = $('#a-err'); err.textContent = '';
    const btn = $('#a-submit'); btn.disabled = true;
    try {
      const s = await getSession(); if (!s) throw new Error('Sign in first');
      const name = $('#a-name').value.trim();
      const slug = slugify(name);
      const iconFile = $('#a-icon').files[0];
      const apkFile = $('#a-apk').files[0];
      validateImage(iconFile); validateApk(apkFile);
      btn.textContent = 'Uploading icon…';
      const iconUrl = await uploadAsset(iconFile, 'icons');
      btn.textContent = 'Uploading screenshots…';
      const shotUrls = [];
      for (const f of Array.from($('#a-shots').files).slice(0, 6)) {
        validateImage(f); shotUrls.push(await uploadAsset(f, 'screenshots'));
      }
      btn.textContent = 'Uploading APK…';
      const apkPath = await uploadApk(apkFile, s.user.id, slug);
      btn.textContent = 'Creating listing…';
      const app = await createAppListing({
        developer_id: s.user.id,
        category_id: $('#a-cat').value || null,
        name, slug,
        package_name: $('#a-pkg').value.trim() || null,
        short_desc: $('#a-short').value.trim(),
        description: $('#a-desc').value.trim(),
        version: $('#a-ver').value.trim(),
        file_size_bytes: apkFile.size,
        icon_url: iconUrl,
        screenshots: shotUrls,
        apk_path: apkPath,
        status: adminMode ? 'scanning' : 'pending',
        scan_status: adminMode ? 'pending' : 'pending',
        featured: false,
      });
      toast(adminMode ? 'APK uploaded — scanning now' : 'Submitted! An admin will review it soon.', 'ok');
      if (onDone) onDone(app); else location.hash = '#/profile';
    } catch (e) { err.textContent = e.message; }
    btn.disabled = false;
    btn.textContent = adminMode ? 'Upload & scan APK' : 'Submit for review';
  });
}
async function renderSubmit() {
  const s = await requireLogin(); if (!s) return;
  page('<div class="sec-head"><h2>Publish your app</h2></div><div class="panel">' + appFormHtml(false) + '</div>');
  await bindAppForm(false, null);
}
async function renderSupport() {
  const s = await getSession();
  page('<div class="two-col">'
    + '<div class="panel"><h3>Contact support</h3>'
    + (s ? '<form id="f-ticket">'
      + '<div class="field"><label>Subject</label><input type="text" id="t-subject" required maxlength="100"></div>'
      + '<div class="field"><label>Message</label><textarea id="t-msg" required placeholder="Describe your issue…"></textarea></div>'
      + '<button class="btn btn-primary btn-sm" type="submit">Send ticket</button></form>'
      : '<p class="hint">Please <a href="#/login" style="color:var(--green)">log in</a> to contact support.</p>')
    + '</div>'
    + '<div class="panel"><h3>Other ways</h3><div class="longtext">📧 Email: support@zahkmi-tiger.example\n🐯 Owner: ZAHKMI TIGER team\n\nWe usually reply within 48 hours. Please include your account email and any error messages.</div>'
    + (s ? '<div id="my-tickets" class="mt">' + loading() + '</div>' : '') + '</div></div>');
  if (s) {
    $('#f-ticket').addEventListener('submit', async ev => {
      ev.preventDefault();
      try { await submitTicket($('#t-subject').value.trim(), $('#t-msg').value.trim()); toast('Ticket sent — we will reply soon', 'ok'); renderSupport(); }
      catch (e) { toast(e.message, 'error'); }
    });
    try {
      const t = await myTickets();
      $('#my-tickets').innerHTML = '<h3 class="mt">My tickets</h3>' + (t.length ? t.map(x =>
        '<div class="review"><div class="rh"><b>' + esc(x.subject) + '</b><span class="badge-status st-' + (x.status === 'open' ? 'pending' : 'approved') + '">' + esc(x.status) + '</span></div>'
        + '<p>' + esc(x.message) + '</p>'
        + (x.reply ? '<p style="color:var(--green)"><b>Support reply:</b> ' + esc(x.reply) + '</p>' : '')).join('')
        : '<p class="hint">No tickets yet.</p>');
    } catch (e) { $('#my-tickets').innerHTML = ''; }
  }
}
async function renderReport(slug) {
  const s = await requireLogin(); if (!s) return;
  let app = null;
  try { app = await getApp(slug); } catch (e) {}
  if (!app) { page(empty('App not found')); return; }
  page('<div class="form-narrow"><div class="form-card"><h2>⚑ Report app</h2>'
    + '<div class="sub">Reporting: <b style="color:var(--cyan)">' + esc(app.name) + '</b></div>'
    + '<form id="f-report">'
    + '<div class="field"><label>Reason</label><select id="rp-reason">'
    + '<option>Malware or suspicious behavior</option><option>Spam or misleading content</option>'
    + '<option>Copyright violation</option><option>Broken APK / does not install</option><option>Other</option></select></div>'
    + '<div class="field"><label>Details</label><textarea id="rp-details" placeholder="Tell us more…"></textarea></div>'
    + '<button class="btn btn-danger btn-sm" type="submit">Submit report</button> '
    + '<a class="btn btn-ghost btn-sm" href="#/app/' + esc(app.slug) + '">Cancel</a></form></div></div>');
  $('#f-report').addEventListener('submit', async ev => {
    ev.preventDefault();
    try {
      await submitReport(app.id, $('#rp-reason').value, $('#rp-details').value.trim());
      toast('Report submitted — our team will review it', 'ok'); location.hash = '#/app/' + app.slug;
    } catch (e) { toast(e.message, 'error'); }
  });
}
function legalPage(title, body) {
  page('<div class="panel" style="max-width:760px;margin:0 auto"><h3 style="font-size:20px">' + esc(title) + '</h3><div class="longtext mt">'
    + esc(body) + '</div><p class="hint mt">Last updated: October 2026 · Contact: support@zahkmi-tiger.example</p></div>');
}
function renderPrivacy() {
  legalPage('Privacy Policy — ZAHKMI TIGER STORE',
    '1. Data we collect: account email, display name, optional avatar, your reviews, favorites, download history and support tickets.\n'
    + '2. Files you upload (icons, screenshots, APKs) are stored in secured object storage. APK binaries are never stored inside database records.\n'
    + '3. Uploaded APKs are scanned with a malware-scanning service before they are published. Scan results (clean/infected) are shown publicly.\n'
    + '4. We never sell your data. Authentication is handled by Supabase with row-level security; passwords are never visible to us or stored in frontend code.\n'
    + '5. You may delete your account data at any time by contacting support.\n'
    + '6. Analytics: this site stores no third-party tracking cookies by default.');
}
function renderTerms() {
  legalPage('Terms of Service — ZAHKMI TIGER STORE',
    '1. ZAHKMI TIGER STORE is an independent marketplace operated by ZAHKMI TIGER. It is not affiliated with, endorsed by, or connected to Google or Google Play.\n'
    + '2. Developers guarantee they own the rights to apps they submit and that their APKs contain no malware, spyware or deceptive code.\n'
    + '3. We may reject, remove or quarantine any app that fails security scanning or violates these terms.\n'
    + '4. Users download and install APKs at their own risk; always review requested permissions before installing.\n'
    + '5. Abusive reviews, spam, or attempts to manipulate ratings lead to account suspension.\n'
    + '6. The Super Admin controls store administration. Admin permissions can only be granted by the Super Admin account.');
}

/* ---------------- pages: admin ---------------- */
async function guardAdmin() {
  const p = await getProfile();
  if (!p || !(p.is_admin || p.is_super_admin)) {
    toast('Admin access only', 'error'); location.hash = '#/'; return null;
  }
  return p;
}
function adminNav(active) {
  const items = [
    ['', 'Dashboard'], ['upload', 'Upload APK'], ['submissions', 'Submissions'],
    ['apps', 'Apps'], ['categories', 'Categories'], ['users', 'Users'],
    ['reviews', 'Reviews'], ['reports', 'Reports'], ['tickets', 'Tickets'],
  ];
  return '<div class="admin-nav">' + items.map(i =>
    '<a href="#/admin' + (i[0] ? '/' + i[0] : '') + '" class="' + (active === i[0] ? 'active' : '') + '">' + i[1] + '</a>').join('') + '</div>';
}
function adminPage(active, title, inner) {
  page('<div class="sec-head"><h2 style="color:var(--pink)">⚡ ' + esc(title) + '</h2></div>' + adminNav(active) + inner);
}
async function renderAdmin(sub) {
  const me = await guardAdmin(); if (!me) return;
  sub = sub || '';
  if (sub === 'upload') return adminUpload();
  if (sub === 'apps') return adminApps();
  if (sub === 'submissions') return adminSubmissions();
  if (sub === 'users') return adminUsers(me);
  if (sub === 'reviews') return adminReviews();
  if (sub === 'reports') return adminReports();
  if (sub === 'tickets') return adminTickets();
  if (sub === 'categories') return adminCategories();
  adminPage('', 'Super Admin Dashboard',
    '<div class="stat-cards" id="stats">' + loading() + '</div>'
    + '<div class="panel mt-lg"><h3>How scanning works</h3><div class="longtext">Every APK uploaded here is sent to the scan-apk Edge Function, which submits it to VirusTotal and only publishes it when the verdict is CLEAN. '
    + 'If the scanner is not configured yet (missing VT_API_KEY), uploads stay in "scanning/pending" state and you can review them under Submissions. '
    + 'Setup: <code>supabase functions deploy scan-apk</code> then <code>supabase secrets set VT_API_KEY=…</code>. Only YOUR Super Admin account can grant admin rights (Admin → Users).</div></div>');
  try {
    const c = await adminCounts();
    $('#stats').innerHTML =
      '<div class="stat-card accent"><b>' + fmtInt(c.users) + '</b><span>Total users</span></div>'
      + '<div class="stat-card accent"><b>' + fmtInt(c.apps) + '</b><span>APK listings</span></div>'
      + '<div class="stat-card accent"><b>' + fmtInt(c.downloads) + '</b><span>Total downloads</span></div>'
      + '<div class="stat-card"><b>' + fmtInt(c.pending) + '</b><span>Pending review</span></div>';
  } catch (e) { $('#stats').innerHTML = errBox(e); }
}
async function adminUpload() {
  adminPage('upload', 'Upload & Publish APK', '<div class="panel">' + appFormHtml(true) + '</div>');
  await bindAppForm(true, async (app) => {
    try {
      const res = await scanApk(app.id);
      if (res && res.ok) toast('Scan complete: CLEAN — app is now live', 'ok');
      else toast('Scanner response: ' + ((res && (res.message || res.error)) || 'unknown') + ' — review it under Submissions', 'info');
    } catch (e) {
      toast('Edge function not deployed or failed — approve manually from Apps', 'info');
    }
    location.hash = '#/admin/apps';
  });
}
async function adminSubmissions() {
  adminPage('submissions', 'Pending Submissions', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminSubmissions();
  try {
    const apps = await adminListApps('pending');
    $('#list').innerHTML = apps.length
      ? '<div class="tablewrap"><table class="admin"><tr><th>App</th><th>Developer</th><th>Size</th><th>Submitted</th><th>Actions</th></tr>'
        + apps.map(a => '<tr>'
          + '<td><div class="cell-app">' + (a.icon_url ? '<img src="' + esc(a.icon_url) + '">' : '') + '<div><b>' + esc(a.name) + '</b><div class="hint" style="margin:0">v' + esc(a.version) + '</div></div></div></td>'
          + '<td>' + esc(a.profiles ? (a.profiles.display_name || a.profiles.email) : '—') + '</td>'
          + '<td>' + fmtSize(a.file_size_bytes) + '</td><td>' + timeAgo(a.created_at) + '</td>'
          + '<td><div class="row-actions">'
          + '<button class="btn btn-primary btn-sm" data-approve="' + a.id + '">Approve</button>'
          + '<button class="btn btn-purple btn-sm" data-scan="' + a.id + '">Scan</button>'
          + '<button class="btn btn-danger btn-sm" data-reject="' + a.id + '">Reject</button>'
          + '</div></td></tr>').join('') + '</table></div>'
      : empty('No pending submissions — the store is clear 🎉', '✅');
    $$('[data-approve]').forEach(b => b.addEventListener('click', async () => {
      try { await adminUpdateApp(b.dataset.approve, { status: 'approved', scan_status: 'clean', rejection_reason: null }); toast('Approved & published', 'ok'); rerender(); }
      catch (e) { toast(e.message, 'error'); }
    }));
    $$('[data-scan]').forEach(b => b.addEventListener('click', async () => {
      try { const res = await scanApk(b.dataset.scan); toast(res && res.ok ? 'Scan complete: CLEAN — published' : 'Scan finished: ' + ((res && (res.message || res.error)) || 'check status'), res && res.ok ? 'ok' : 'info'); rerender(); }
      catch (e) { toast('Scanner unavailable: ' + e.message, 'error'); }
    }));
    $$('[data-reject]').forEach(b => b.addEventListener('click', async () => {
      const reason = prompt('Rejection reason (shown to the developer):');
      if (reason == null) return;
      try { await adminUpdateApp(b.dataset.reject, { status: 'rejected', rejection_reason: reason }); toast('Rejected', 'ok'); rerender(); }
      catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminApps() {
  adminPage('apps', 'Manage Apps', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminApps();
  try {
    const apps = await adminListApps();
    $('#list').innerHTML = '<div class="tablewrap"><table class="admin"><tr><th>App</th><th>Developer</th><th>Status</th><th>Stats</th><th>Actions</th></tr>'
      + apps.map(a => '<tr>'
        + '<td><div class="cell-app">' + (a.icon_url ? '<img src="' + esc(a.icon_url) + '">' : '') + '<div><a href="#/app/' + esc(a.slug) + '" style="color:var(--cyan)"><b>' + esc(a.name) + '</b></a><div class="hint" style="margin:0">v' + esc(a.version) + '</div></div></div></td>'
        + '<td>' + esc(a.profiles ? (a.profiles.display_name || a.profiles.email) : '—') + '</td>'
        + '<td>' + statusBadge(a) + (a.rejection_reason ? '<div class="hint" style="margin:0;color:var(--red)">' + esc(a.rejection_reason) + '</div>' : '') + '</td>'
        + '<td>⬇ ' + fmtInt(a.downloads_count) + '<br>' + stars(a.rating_avg) + ' ' + a.rating_count + '</td>'
        + '<td><div class="row-actions">'
        + (a.status !== 'approved' ? '<button class="btn btn-primary btn-sm" data-approve="' + a.id + '">Approve</button>' : '')
        + (a.status === 'approved' ? '<button class="btn btn-ghost btn-sm" data-unapprove="' + a.id + '">Unpublish</button>' : '')
        + '<button class="btn btn-ghost btn-sm" data-feat="' + a.id + '" data-on="' + (a.featured ? '1' : '0') + '">' + (a.featured ? '★ Unfeature' : '☆ Feature') + '</button>'
        + '<button class="btn btn-danger btn-sm" data-del="' + a.id + '">Delete</button>'
        + '</div></td></tr>').join('') + '</table></div>';
    $$('[data-approve]').forEach(b => b.addEventListener('click', async () => { try { await adminUpdateApp(b.dataset.approve, { status: 'approved', scan_status: 'clean' }); toast('Published', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); } }));
    $$('[data-unapprove]').forEach(b => b.addEventListener('click', async () => { try { await adminUpdateApp(b.dataset.unapprove, { status: 'rejected', rejection_reason: 'Unpublished by admin' }); toast('Unpublished', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); } }));
    $$('[data-feat]').forEach(b => b.addEventListener('click', async () => { try { await adminUpdateApp(b.dataset.feat, { featured: b.dataset.on !== '1' }); toast('Updated', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); } }));
    $$('[data-del]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('Delete this app AND its APK file? This cannot be undone.')) return;
      const app = apps.find(x => x.id === b.dataset.del);
      try { await adminDeleteApp(app); toast('Deleted', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminUsers(me) {
  adminPage('users', 'Manage Users', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminUsers(me);
  try {
    const users = await adminListUsers();
    $('#list').innerHTML = '<div class="tablewrap"><table class="admin"><tr><th>User</th><th>Role</th><th>Joined</th><th>Actions</th></tr>'
      + users.map(u => '<tr>'
        + '<td><div class="cell-app">' + avatarHtml(u) + '<div><b>' + esc(u.display_name || '—') + '</b><div class="hint" style="margin:0">' + esc(u.email) + '</div></div></div></td>'
        + '<td>' + (u.is_super_admin ? '<span class="badge-status st-infected" style="background:var(--purple)">SUPER ADMIN</span>'
          : u.is_admin ? '<span class="badge-status st-approved">ADMIN</span>' : '<span class="badge-status st-pending">MEMBER</span>') + '</td>'
        + '<td>' + fmtDate(u.created_at) + '</td>'
        + '<td><div class="row-actions">'
        + (u.is_super_admin ? '<span class="hint" style="margin:0">Owner account — locked</span>'
          : '<label style="font-size:12px;color:var(--muted)"><input type="checkbox" data-admin="' + u.id + '" ' + (u.is_admin ? 'checked' : '') + (me.is_super_admin ? '' : ' disabled') + '> admin</label>'
          + (me.is_super_admin ? ' <button class="btn btn-danger btn-sm" data-deluser="' + u.id + '">Delete</button>' : ''))
        + '</div></td></tr>').join('') + '</table></div>'
      + (me.is_super_admin ? '' : '<p class="hint mt">Only the Super Admin can change admin permissions or delete users.</p>');
    $$('[data-admin]').forEach(cb => cb.addEventListener('change', async () => {
      try { await adminSetAdmin(cb.dataset.admin, cb.checked); toast('Admin permission updated', 'ok'); }
      catch (e) { toast(e.message, 'error'); cb.checked = !cb.checked; }
    }));
    $$('[data-deluser]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('Delete this user and all their data?')) return;
      try { await adminDeleteUser(b.dataset.deluser); toast('User deleted', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminReviews() {
  adminPage('reviews', 'Moderate Reviews', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminReviews();
  try {
    const rows = await adminListReviews();
    $('#list').innerHTML = rows.length ? '<div class="tablewrap"><table class="admin"><tr><th>Review</th><th>App</th><th>User</th><th>Actions</th></tr>'
      + rows.map(r => '<tr><td>' + stars(r.rating) + '<div class="hint" style="margin:4px 0 0;max-width:320px">' + esc(r.comment || '—') + '</div></td>'
        + '<td>' + esc(r.apps ? r.apps.name : '—') + '</td><td>' + esc(r.profiles ? (r.profiles.display_name || r.profiles.email) : '—') + '</td>'
        + '<td><button class="btn btn-danger btn-sm" data-del="' + r.id + '">Delete</button></td></tr>').join('') + '</table></div>'
      : empty('No reviews yet', '💬');
    $$('[data-del]').forEach(b => b.addEventListener('click', async () => {
      try { await deleteReview(b.dataset.del); toast('Review deleted', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminReports() {
  adminPage('reports', 'Handle Reports', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminReports();
  try {
    const rows = await adminListReports();
    $('#list').innerHTML = rows.length ? '<div class="tablewrap"><table class="admin"><tr><th>Report</th><th>App</th><th>By</th><th>Status</th><th>Actions</th></tr>'
      + rows.map(r => '<tr><td><b>' + esc(r.reason) + '</b><div class="hint" style="margin:0;max-width:280px">' + esc(r.details || '') + '</div></td>'
        + '<td>' + esc(r.apps ? r.apps.name : '—') + '</td><td>' + esc(r.profiles ? (r.profiles.display_name || r.profiles.email) : '—') + '</td>'
        + '<td><span class="badge-status st-' + (r.status === 'open' ? 'pending' : 'approved') + '">' + esc(r.status) + '</span></td>'
        + '<td><div class="row-actions">'
        + (r.status === 'open' ? '<button class="btn btn-primary btn-sm" data-resolve="' + r.id + '">Resolve</button><button class="btn btn-ghost btn-sm" data-dismiss="' + r.id + '">Dismiss</button>' : '')
        + '</div></td></tr>').join('') + '</table></div>'
      : empty('No reports — nice and clean 🎉', '✅');
    $$('[data-resolve]').forEach(b => b.addEventListener('click', async () => { try { await adminUpdateReport(b.dataset.resolve, 'resolved'); toast('Marked resolved', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); } }));
    $$('[data-dismiss]').forEach(b => b.addEventListener('click', async () => { try { await adminUpdateReport(b.dataset.dismiss, 'dismissed'); toast('Dismissed', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); } }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminTickets() {
  adminPage('tickets', 'Support Tickets', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminTickets();
  try {
    const rows = await adminListTickets();
    $('#list').innerHTML = rows.length ? '<div class="tablewrap"><table class="admin"><tr><th>Ticket</th><th>User</th><th>Status</th><th>Actions</th></tr>'
      + rows.map(t => '<tr><td><b>' + esc(t.subject) + '</b><div class="hint" style="margin:0;max-width:300px">' + esc(t.message) + '</div>'
        + (t.reply ? '<div class="hint" style="margin:4px 0 0;color:var(--green)">Reply: ' + esc(t.reply) + '</div>' : '') + '</td>'
        + '<td>' + esc(t.profiles ? (t.profiles.display_name || t.profiles.email) : '—') + '</td>'
        + '<td><span class="badge-status st-' + (t.status === 'open' ? 'pending' : 'approved') + '">' + esc(t.status) + '</span></td>'
        + '<td><div class="row-actions">'
        + '<button class="btn btn-primary btn-sm" data-reply="' + t.id + '">Reply</button>'
        + (t.status !== 'closed' ? '<button class="btn btn-ghost btn-sm" data-close="' + t.id + '">Close</button>' : '')
        + '</div></td></tr>').join('') + '</table></div>'
      : empty('No support tickets', '🎫');
    $$('[data-reply]').forEach(b => b.addEventListener('click', async () => {
      const reply = prompt('Reply to user (will be shown in their Support page):');
      if (reply == null) return;
      try { await adminUpdateTicket(b.dataset.reply, { reply, status: 'answered' }); toast('Replied', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
    $$('[data-close]').forEach(b => b.addEventListener('click', async () => {
      try { await adminUpdateTicket(b.dataset.close, { status: 'closed' }); toast('Ticket closed', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}
async function adminCategories() {
  adminPage('categories', 'Manage Categories', '<div id="list">' + loading() + '</div>');
  const rerender = () => adminCategories();
  try {
    const cats = await listCategories();
    $('#list').innerHTML = '<div class="panel"><h3>Add category</h3><form id="f-cat" class="row-actions">'
      + '<input type="text" id="c-name" placeholder="e.g. Games, Tools, Education…" required style="flex:1;min-width:200px" class="input">'
      + '<button class="btn btn-primary btn-sm" type="submit">Add</button></form></div>'
      + '<div class="tablewrap mt"><table class="admin"><tr><th>Name</th><th>Slug</th><th>Apps</th><th>Actions</th></tr>'
      + cats.map(c => '<tr><td>' + esc(c.name) + '</td><td>' + esc(c.slug) + '</td><td>—</td>'
        + '<td><button class="btn btn-danger btn-sm" data-del="' + c.id + '">Delete</button></td></tr>').join('')
      + '</table></div>';
    $('#f-cat').addEventListener('submit', async ev => {
      ev.preventDefault();
      try { await addCategory($('#c-name').value.trim()); toast('Category added', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    });
    $$('[data-del]').forEach(b => b.addEventListener('click', async () => {
      if (!confirm('Delete this category?')) return;
      try { await deleteCategory(b.dataset.del); toast('Deleted', 'ok'); rerender(); } catch (e) { toast(e.message, 'error'); }
    }));
  } catch (e) { $('#list').innerHTML = errBox(e); }
}

/* ---------------- router ---------------- */
const ROUTES = {
  '': renderHome, home: renderHome, categories: renderCategories, category: renderCategory,
  search: renderSearch, app: renderAppDetail, login: renderLogin, signup: renderSignup,
  reset: renderReset, profile: renderProfile, favorites: renderFavorites, downloads: renderDownloads,
  submit: renderSubmit, support: renderSupport, report: renderReport, privacy: renderPrivacy, terms: renderTerms,
};
function parseHash() {
  const h = location.hash.replace(/^#\/?/, '');
  const parts = h.split('/').map(decodeURIComponent);
  return { page: parts[0] || '', param: parts[1] || null };
}
async function route() {
  const { page, param } = parseHash();
  setActiveNav(page);
  if (page === 'admin') return renderAdmin(param);
  const fn = ROUTES[page];
  if (fn) return fn(param);
  return renderHome();
}
function setActiveNav(page) {
  const map = { '': 'home', home: 'home', categories: 'categories', category: 'categories', submit: 'submit', support: 'support', admin: 'admin' };
  const active = map[page] || '';
  $$('#mainnav a').forEach(a => a.classList.toggle('active', a.dataset.nav === active));
}

/* ---------------- boot ---------------- */
async function refreshAuthZone() {
  const zone = $('#auth-zone'); if (!zone) return;
  const s = await getSession().catch(() => null);
  if (!s) {
    zone.innerHTML = '<a class="btn btn-ghost btn-sm" href="#/login">Log in</a><a class="btn btn-primary btn-sm" href="#/signup">Sign up</a>';
    $('.admin-link').classList.add('hidden'); return;
  }
  const p = await getProfile().catch(() => null);
  const name = p ? (p.display_name || 'Account') : 'Account';
  zone.innerHTML = '<a class="userchip" href="#/profile">' + avatarHtml(p) + '<span>' + esc(name) + '</span></a>'
    + '<button class="btn btn-ghost btn-sm" id="btn-logout">Logout</button>';
  $('#btn-logout').addEventListener('click', async () => {
    await signOut(); toast('Logged out — see you, tiger', 'ok');
    await refreshAuthZone(); location.hash = '#/'; route();
  });
  if ($('.admin-link')) $('.admin-link').classList.toggle('hidden', !(p && (p.is_admin || p.is_super_admin)));
}
function paintLogos() {
  const b = $('#brand-logo'), f = $('#foot-logo');
  if (b) b.innerHTML = tigerSvg(38);
  if (f) f.innerHTML = tigerSvg(26);
}
document.addEventListener('DOMContentLoaded', async () => {
  paintLogos();
  if (window.supabase && CFG && CFG.SUPABASE_URL.indexOf('YOUR-') === -1) {
    window.sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY);
    sb.auth.onAuthStateChange(() => { refreshAuthZone(); });
  } else {
    window.sb = null;
  }
  $('#nav-toggle').addEventListener('click', () => $('#mainnav').classList.toggle('open'));
  $('#mainnav').addEventListener('click', () => $('#mainnav').classList.remove('open'));
  $('#search-form').addEventListener('submit', ev => {
    ev.preventDefault();
    const q = $('#search-input').value.trim();
    if (q) location.hash = '#/search/' + encodeURIComponent(q);
  });
  await refreshAuthZone();
  window.addEventListener('hashchange', route);
  route();
});
