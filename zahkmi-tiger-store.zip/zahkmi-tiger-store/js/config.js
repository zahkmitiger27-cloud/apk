/* ============================================================================
   ZAHKMI TIGER STORE - configuration
   Replace the two values below with your own Supabase project credentials
   (Supabase Dashboard -> Project Settings -> API).
   The anon key is PUBLIC by design - security is enforced by RLS policies.
   NEVER put the service-role key or any private API key in this file.
   ========================================================================== */
window.ZTS_CONFIG = {
  SUPABASE_URL: 'https://YOUR-PROJECT-REF.supabase.co',
  SUPABASE_ANON_KEY: 'YOUR-ANON-PUBLIC-KEY',
  MAX_APK_BYTES: 200 * 1024 * 1024,   // 200 MB per APK
  MAX_ICON_BYTES: 2 * 1024 * 1024,    // 2 MB
  SITE_NAME: 'ZAHKMI TIGER STORE',
};
