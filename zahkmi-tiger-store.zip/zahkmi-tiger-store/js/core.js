/* ============================================================================
   ZAHKMI TIGER STORE - core: supabase client, helpers, auth & data API
   ========================================================================== */
'use strict';

const CFG = window.ZTS_CONFIG;
window.sb = null; // initialized on DOMContentLoaded (needs config + CDN client)

/* ---------- DOM helpers ---------- */
const $  = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, c =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtSize(b) {
  b = Number(b) || 0; if (b <= 0) return '—';
  const u = ['B', 'KB', 'MB', 'GB']; let i = 0;
  while (b >= 1024 && i < 3) { b /= 1024; i++; }
  return (i ? b.toFixed(1) : b) + ' ' + u[i];
}
function fmtDate(d) {
  return d ? new Date(d).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : '—';
}
function timeAgo(d) {
  const s = (Date.now() - new Date(d)) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm ago';
  if (s < 86400) return Math.floor(s / 3600) + 'h ago';
  return Math.floor(s / 86400) + 'd ago';
}
function slugify(t) {
  return String(t || '').toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 48)
    + '-' + Math.random().toString(36).slice(2, 7);
}
function toast(msg, type) {
  type = type || 'info';
  const box = $('#toasts'); if (!box) return;
  const el = document.createElement('div');
  el.className = 'toast ' + type; el.textContent = msg;
  box.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .4s'; setTimeout(() => el.remove(), 400); }, 3600);
}
function stars(r) {
  r = Math.round(Number(r) || 0); let out = '';
  for (let i = 1; i <= 5; i++) out += '<span class="' + (i <= r ? '' : 'off') + '">★</span>';
  return '<span class="star">' + out + '</span>';
}
function initials(name) {
  return String(name || '?').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}
function avatarHtml(p, cls) {
  const url = p && (p.avatar_url || (p.profiles && p.profiles.avatar_url));
  const name = p && (p.display_name || p.email || (p.profiles && p.profiles.display_name) || '?');
  if (url) return '<span class="avatar ' + (cls || '') + '"><img src="' + esc(url) + '" alt=""></span>';
  return '<span class="avatar ' + (cls || '') + '">' + esc(initials(name)) + '</span>';
}

/* Brand logo (original geometric tiger, neon gradient) */
function tigerSvg(size) {
  return '<svg viewBox="0 0 64 64" width="' + (size || 38) + '" height="' + (size || 38) + '" fill="none" aria-hidden="true">'
    + '<defs><linearGradient id="tg" x1="0" y1="0" x2="1" y2="1">'
    + '<stop offset="0" stop-color="#00ff9d"/><stop offset=".5" stop-color="#22d3ee"/><stop offset="1" stop-color="#a855f7"/></linearGradient></defs>'
    + '<path d="M12 10l14 8h12l14-8-2 16 4 8c0 14-10 24-20 24S10 48 10 34l4-8-2-16z" stroke="url(#tg)" stroke-width="2.6" stroke-linejoin="round"/>'
    + '<path d="M23 39l6 6 3-3 3 3 6-6" stroke="#22d3ee" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
    + '<circle cx="23" cy="30" r="2.6" fill="#00ff9d"/><circle cx="41" cy="30" r="2.6" fill="#00ff9d"/>'
    + '<path d="M32 20v8M26 18l2 7M38 18l-2 7" stroke="#a855f7" stroke-width="2" stroke-linecap="round"/></svg>';
}

/* ---------- auth ---------- */
async function getSession() {
  const { data } = await sb.auth.getSession();
  return data.session;
}
async function getProfile() {
  const s = await getSession();
  if (!s) return null;
  const { data } = await sb.from('profiles').select('*').eq('id', s.user.id).single();
  return data;
}
async function isAdminUser() {
  const p = await getProfile();
  return !!(p && (p.is_admin || p.is_super_admin));
}
async function signUp(email, password, displayName) {
  const { error } = await sb.auth.signUp({
    email, password,
    options: { data: { full_name: displayName }, emailRedirectTo: location.origin + '/#/' },
  });
  if (error) throw error;
}
async function signIn(email, password) {
  const { error } = await sb.auth.signInWithPassword({ email, password });
  if (error) throw error;
}
async function signInGoogle() {
  const { error } = await sb.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: location.origin + '/#/' },
  });
  if (error) throw error;
}
async function sendReset(email) {
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + '/#/' });
  if (error) throw error;
}
async function updatePassword(newPassword) {
  const { error } = await sb.auth.updateUser({ password: newPassword });
  if (error) throw error;
}
async function signOut() { await sb.auth.signOut(); }
async function updateProfileFields(patch) {
  const s = await getSession(); if (!s) throw new Error('Not signed in');
  const { error } = await sb.from('profiles').update(patch).eq('id', s.user.id);
  if (error) throw error;
}

/* ---------- data API ---------- */
async function listCategories() {
  const { data, error } = await sb.from('categories').select('*').order('name');
  if (error) throw error; return data || [];
}
async function listApprovedApps(opts) {
  opts = opts || {};
  let q = sb.from('apps')
    .select('*, profiles:developer_id(email, display_name, avatar_url), categories:category_id(name, slug)')
    .eq('status', 'approved')
    .order('created_at', { ascending: false });
  if (opts.featured) q = q.eq('featured', true);
  if (opts.category) q = q.eq('categories.slug', opts.category);
  if (opts.limit) q = q.limit(opts.limit);
  const { data, error } = await q;
  if (error) throw error; return data || [];
}
async function searchApps(term) {
  const { data, error } = await sb.from('apps')
    .select('*, profiles:developer_id(email, display_name), categories:category_id(name, slug)')
    .eq('status', 'approved')
    .or('name.ilike.%' + term + '%,short_desc.ilike.%' + term + '%,description.ilike.%' + term + '%')
    .order('downloads_count', { ascending: false });
  if (error) throw error; return data || [];
}
async function getApp(slug) {
  const { data, error } = await sb.from('apps')
    .select('*, profiles:developer_id(email, display_name, avatar_url), categories:category_id(name, slug)')
    .eq('slug', slug).maybeSingle();
  if (error) throw error;
  if (!data) return null;
  const me = await getProfile();
  const admin = !!(me && (me.is_admin || me.is_super_admin));
  if (data.status !== 'approved' && data.developer_id !== (me && me.id) && !admin) return null;
  return data;
}
async function listReviews(appId) {
  const { data, error } = await sb.from('reviews')
    .select('*, profiles:user_id(email, display_name, avatar_url)')
    .eq('app_id', appId).order('created_at', { ascending: false });
  if (error) throw error; return data || [];
}
async function myReview(appId) {
  const s = await getSession(); if (!s) return null;
  const { data } = await sb.from('reviews').select('*').eq('app_id', appId).eq('user_id', s.user.id).maybeSingle();
  return data;
}
async function saveReview(appId, rating, comment) {
  const s = await getSession(); if (!s) throw new Error('Sign in to review');
  const { error } = await sb.from('reviews').upsert(
    { app_id: appId, user_id: s.user.id, rating, comment },
    { onConflict: 'app_id,user_id' });
  if (error) throw error;
}
async function deleteReview(id) {
  const { error } = await sb.from('reviews').delete().eq('id', id);
  if (error) throw error;
}
async function isFav(appId) {
  const s = await getSession(); if (!s) return false;
  const { data } = await sb.from('favorites').select('app_id').eq('app_id', appId).eq('user_id', s.user.id).maybeSingle();
  return !!data;
}
async function toggleFav(appId) {
  const s = await getSession(); if (!s) throw new Error('Sign in to save favorites');
  const fav = await isFav(appId);
  if (fav) { const { error } = await sb.from('favorites').delete().eq('app_id', appId).eq('user_id', s.user.id); if (error) throw error; return false; }
  const { error } = await sb.from('favorites').insert({ app_id: appId, user_id: s.user.id });
  if (error) throw error; return true;
}
async function listFavorites() {
  const s = await getSession(); if (!s) return [];
  const { data, error } = await sb.from('favorites')
    .select('created_at, apps(*)')
    .eq('user_id', s.user.id).order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map(r => r.apps).filter(a => a && a.status === 'approved');
}
async function listMyDownloads() {
  const s = await getSession(); if (!s) return [];
  const { data, error } = await sb.from('downloads')
    .select('created_at, apps(*)')
    .eq('user_id', s.user.id).order('created_at', { ascending: false });
  if (error) throw error;
  return (data || []).map(r => ({ at: r.created_at, app: r.apps }));
}
async function installApp(app) {
  if (!app.apk_path) throw new Error('APK file not available yet');
  const { data, error } = await sb.storage.from('apks').createSignedUrl(app.apk_path, 300);
  if (error) throw error;
  const a = document.createElement('a');
  a.href = data.signedUrl; a.download = app.slug + '.apk';
  document.body.appendChild(a); a.click(); a.remove();
  await sb.rpc('increment_downloads', { p_app_id: app.id });
  const s = await getSession();
  if (s) await sb.from('downloads').insert({ user_id: s.user.id, app_id: app.id }).then(() => {}, () => {});
}
async function submitReport(appId, reason, details) {
  const s = await getSession(); if (!s) throw new Error('Sign in to report');
  const { error } = await sb.from('reports').insert({ app_id: appId, user_id: s.user.id, reason, details });
  if (error) throw error;
}
async function submitTicket(subject, message) {
  const s = await getSession(); if (!s) throw new Error('Sign in to contact support');
  const { error } = await sb.from('support_tickets').insert({ user_id: s.user.id, subject, message });
  if (error) throw error;
}
async function myTickets() {
  const s = await getSession(); if (!s) return [];
  const { data, error } = await sb.from('support_tickets').select('*').eq('user_id', s.user.id).order('created_at', { ascending: false });
  if (error) throw error; return data || [];
}

/* uploads */
function validateApk(file) {
  if (!file) throw new Error('Choose an APK file');
  if (!file.name.toLowerCase().endsWith('.apk')) throw new Error('Only .apk files are allowed');
  if (file.size > CFG.MAX_APK_BYTES) throw new Error('APK too large (max ' + fmtSize(CFG.MAX_APK_BYTES) + ')');
}
function validateImage(file) {
  if (!file) return;
  if (!/^image\/(png|jpe?g|webp)$/.test(file.type)) throw new Error('Icon/screenshots must be PNG, JPG or WebP');
  if (file.size > CFG.MAX_ICON_BYTES) throw new Error('Image too large (max ' + fmtSize(CFG.MAX_ICON_BYTES) + ')');
}
async function uploadAsset(file, folder) {
  const ext = (file.name.split('.').pop() || 'png').toLowerCase();
  const path = folder + '/' + crypto.randomUUID() + '.' + ext;
  const { error } = await sb.storage.from('store-assets').upload(path, file);
  if (error) throw error;
  const { data } = sb.storage.from('store-assets').getPublicUrl(path);
  return data.publicUrl;
}
async function uploadApk(file, uid, slug) {
  const path = uid + '/' + slug + '.apk';
  const { error } = await sb.storage.from('apks').upload(path, file, { upsert: true });
  if (error) throw error;
  return path;
}
async function createAppListing(fields) {
  const { data, error } = await sb.from('apps').insert(fields).select().single();
  if (error) throw error; return data;
}

/* ---------- admin API ---------- */
async function adminCounts() {
  const [u, a, d, p] = await Promise.all([
    sb.from('profiles').select('id', { count: 'exact', head: true }),
    sb.from('apps').select('id', { count: 'exact', head: true }),
    sb.from('apps').select('downloads_count'),
    sb.from('apps').select('id', { count: 'exact', head: true }).eq('status', 'pending'),
  ]);
  return {
    users: u.count || 0,
    apps: a.count || 0,
    pending: p.count || 0,
    downloads: (d.data || []).reduce((s, r) => s + (r.downloads_count || 0), 0),
  };
}
async function adminListApps(statusFilter) {
  let q = sb.from('apps').select('*, profiles:developer_id(email, display_name)').order('created_at', { ascending: false });
  if (statusFilter) q = q.eq('status', statusFilter);
  const { data, error } = await q;
  if (error) throw error; return data || [];
}
async function adminUpdateApp(id, patch) {
  const { error } = await sb.from('apps').update(patch).eq('id', id);
  if (error) throw error;
}
async function adminDeleteApp(app) {
  if (app.apk_path) await sb.storage.from('apks').remove([app.apk_path]).then(() => {}, () => {});
  const { error } = await sb.from('apps').delete().eq('id', app.id);
  if (error) throw error;
}
async function adminListUsers() {
  const { data, error } = await sb.from('profiles').select('*').order('created_at', { ascending: false });
  if (error) throw error; return data || [];
}
async function adminSetAdmin(userId, is_admin) {
  const me = await getProfile();
  if (!me || !me.is_super_admin) throw new Error('Only the Super Admin can change admin permissions');
  const { error } = await sb.from('profiles').update({ is_admin }).eq('id', userId);
  if (error) throw error;
}
async function adminDeleteUser(userId) {
  const me = await getProfile();
  if (!me || !me.is_super_admin) throw new Error('Only the Super Admin can delete users');
  const { error } = await sb.from('profiles').delete().eq('id', userId);
  if (error) throw error;
}
async function adminListReviews() {
  const { data, error } = await sb.from('reviews')
    .select('*, profiles:user_id(email, display_name), apps:app_id(name, slug)')
    .order('created_at', { ascending: false }).limit(200);
  if (error) throw error; return data || [];
}
async function adminListReports() {
  const { data, error } = await sb.from('reports')
    .select('*, profiles:user_id(email, display_name), apps:app_id(name, slug)')
    .order('created_at', { ascending: false });
  if (error) throw error; return data || [];
}
async function adminUpdateReport(id, status) {
  const { error } = await sb.from('reports').update({ status }).eq('id', id);
  if (error) throw error;
}
async function adminListTickets() {
  const { data, error } = await sb.from('support_tickets')
    .select('*, profiles:user_id(email, display_name)')
    .order('created_at', { ascending: false });
  if (error) throw error; return data || [];
}
async function adminUpdateTicket(id, patch) {
  const { error } = await sb.from('support_tickets').update(patch).eq('id', id);
  if (error) throw error;
}
async function addCategory(name) {
  const slug = name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  const { error } = await sb.from('categories').insert({ name, slug });
  if (error) throw error;
}
async function deleteCategory(id) {
  const { error } = await sb.from('categories').delete().eq('id', id);
  if (error) throw error;
}
/* malware scan via edge function (optional; manual approve fallback exists) */
async function scanApk(appId) {
  const { data, error } = await sb.functions.invoke('scan-apk', { body: { appId } });
  if (error) throw error;
  return data;
}
