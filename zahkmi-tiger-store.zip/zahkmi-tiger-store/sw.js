/* ZAHKMI TIGER STORE - service worker (app-shell PWA) */
const CACHE = 'zts-v1';
const SHELL = ['./', './index.html', './styles.css', './js/config.js', './js/core.js', './js/app.js',
  './manifest.webmanifest', './assets/icon-192.png', './assets/icon-512.png'];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET' || url.origin !== location.origin) return; // network for API/Supabase
  e.respondWith(caches.match(e.request).then((r) => r || fetch(e.request)));
});
